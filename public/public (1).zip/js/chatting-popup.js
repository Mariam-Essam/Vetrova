$(".header").click(function(){
    $(".messagecontent").slideToggle(0);
});
$(".close").click(function(){
    $(".form-container").hide(0);
});

