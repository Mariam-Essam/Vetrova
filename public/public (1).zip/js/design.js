// $(".women-choice").click(function(){
//     $(".request-type").hide(100);
//     $(".women-types").show(120);
//     $(".finish-upload-inputs").hide(100);
//     $(".finish-noupload-inputs").hide(100);
//     $(".types-photos").hide(100);
// })
// $(".men-choice").click(function(){
//     $(".request-type").hide(100);
//     $(".men-types").show(120);
//     $(".finish-upload-inputs").hide(100);
//     $(".finish-noupload-inputs").hide(100);
//     $(".types-photos").hide(100);
// })
// $(".kids-choice").click(function(){
//     $(".request-type").hide(100);
//     $(".kids-types").show(120);
//     $(".finish-upload-inputs").hide(100);
//     $(".finish-noupload-inputs").hide(100);
//     $(".types-photos").hide(100);
// })
// $("#prev-choice-types1").click(function(){
//     $(".request-type").show(120);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
//     $(".finish-upload-inputs").hide(100);
//     $(".finish-noupload-inputs").hide(100);
//     $(".types-photos").hide(100);
// })
// $("#prev-choice-types2").click(function(){
//     $(".request-type").show(120);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
//     $(".finish-upload-inputs").hide(100);
//     $(".finish-noupload-inputs").hide(100);
//     $(".types-photos").hide(100);
// })
// $("#prev-choice-types3").click(function(){
//     $(".request-type").show(120);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
//     $(".finish-upload-inputs").hide(100);
//     $(".finish-noupload-inputs").hide(100);
//     $(".types-photos").hide(100);
// })
// $("#prev-choice-types4").click(function(){
//     $(".request-type").show(120);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
//     $(".finish-upload-inputs").hide(100);
//     $(".finish-noupload-inputs").hide(100);
//     $(".types-photos").hide(100);
// })
// $("#prev-choice-types5").click(function(){
//     $(".request-type").show(120);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
//     $(".finish-upload-inputs").hide(100);
//     $(".finish-noupload-inputs").hide(100);
//     $(".types-photos").hide(100);
// })
// $(".women-types .shirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".women-types-photos").show(120);
//     $(".women-shirts").show(120);
//     $(".women-tshirts").hide(100);
//     $(".women-trousers").hide(100);
//     $(".women-skirts").hide(100);
//     $(".women-skirts-shirts").hide(100);
//     $(".women-skirts-tshirts").hide(100);
//     $(".women-trousers-shirts").hide(100);
//     $(".women-trousers-tshirts").hide(100);
//     $(".women-dress").hide(100);
//     $(".women-suit").hide(100);
//     $(".women-hoddy").hide(100);
//     $(".women-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".women-types .tshirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".women-types-photos").show(120);
//     $(".women-shirts").hide(100);
//     $(".women-tshirts").show(120);
//     $(".women-trousers").hide(100);
//     $(".women-skirts").hide(100);
//     $(".women-skirts-shirts").hide(100);
//     $(".women-skirts-tshirts").hide(100);
//     $(".women-trousers-shirts").hide(100);
//     $(".women-trousers-tshirts").hide(100);
//     $(".women-dress").hide(100);
//     $(".women-suit").hide(100);
//     $(".women-hoddy").hide(100);
//     $(".women-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".women-types .trouser-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".women-types-photos").show(120);
//     $(".women-shirts").hide(100);
//     $(".women-tshirts").hide(100);
//     $(".women-trousers").show(120);
//     $(".women-skirts").hide(100);
//     $(".women-skirts-shirts").hide(100);
//     $(".women-skirts-tshirts").hide(100);
//     $(".women-trousers-shirts").hide(100);
//     $(".women-trousers-tshirts").hide(100);
//     $(".women-dress").hide(100);
//     $(".women-suit").hide(100);
//     $(".women-hoddy").hide(100);
//     $(".women-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".women-types .skirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".women-types-photos").show(120);
//     $(".women-shirts").hide(100);
//     $(".women-tshirts").hide(100);
//     $(".women-trousers").hide(100);
//     $(".women-skirts").show(120);
//     $(".women-skirts-shirts").hide(100);
//     $(".women-skirts-tshirts").hide(100);
//     $(".women-trousers-shirts").hide(100);
//     $(".women-trousers-tshirts").hide(100);
//     $(".women-dress").hide(100);
//     $(".women-suit").hide(100);
//     $(".women-hoddy").hide(100);
//     $(".women-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".women-types .skirt-shirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".women-types-photos").show(120);
//     $(".women-shirts").hide(100);
//     $(".women-tshirts").hide(100);
//     $(".women-trousers").hide(100);
//     $(".women-skirts").hide(100);
//     $(".women-skirts-shirts").show(120);
//     $(".women-skirts-tshirts").hide(100);
//     $(".women-trousers-shirts").hide(100);
//     $(".women-trousers-tshirts").hide(100);
//     $(".women-dress").hide(100);
//     $(".women-suit").hide(100);
//     $(".women-hoddy").hide(100);
//     $(".women-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".women-types .skirt-tshirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".women-types-photos").show(120);
//     $(".women-shirts").hide(100);
//     $(".women-tshirts").hide(100);
//     $(".women-trousers").hide(100);
//     $(".women-skirts").hide(100);
//     $(".women-skirts-shirts").hide(100);
//     $(".women-skirts-tshirts").show(120);
//     $(".women-trousers-shirts").hide(100);
//     $(".women-trousers-tshirts").hide(100);
//     $(".women-dress").hide(100);
//     $(".women-suit").hide(100);
//     $(".women-hoddy").hide(100);
//     $(".women-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".women-types .trouser-shirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".women-types-photos").show(120);
//     $(".women-shirts").hide(100);
//     $(".women-tshirts").hide(100);
//     $(".women-trousers").hide(100);
//     $(".women-skirts").hide(100);
//     $(".women-skirts-shirts").hide(100);
//     $(".women-skirts-tshirts").hide(100);
//     $(".women-trousers-shirts").show(120);
//     $(".women-trousers-tshirts").hide(100);
//     $(".women-dress").hide(100);
//     $(".women-suit").hide(100);
//     $(".women-hoddy").hide(100);
//     $(".women-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".women-types .trouser-tshirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".women-types-photos").show(120);
//     $(".women-shirts").hide(100);
//     $(".women-tshirts").hide(100);
//     $(".women-trousers").hide(100);
//     $(".women-skirts").hide(100);
//     $(".women-skirts-shirts").hide(100);
//     $(".women-skirts-tshirts").hide(100);
//     $(".women-trousers-shirts").hide(100);
//     $(".women-trousers-tshirts").show(120);
//     $(".women-dress").hide(100);
//     $(".women-suit").hide(100);
//     $(".women-hoddy").hide(100);
//     $(".women-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".women-types .dress-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".women-types-photos").show(120);
//     $(".women-shirts").hide(100);
//     $(".women-tshirts").hide(100);
//     $(".women-trousers").hide(100);
//     $(".women-skirts").hide(100);
//     $(".women-skirts-shirts").hide(100);
//     $(".women-skirts-tshirts").hide(100);
//     $(".women-trousers-shirts").hide(100);
//     $(".women-trousers-tshirts").hide(100);
//     $(".women-dress").show(120);
//     $(".women-suit").hide(100);
//     $(".women-hoddy").hide(100);
//     $(".women-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".women-types .suit-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".women-types-photos").show(120);
//     $(".women-shirts").hide(100);
//     $(".women-tshirts").hide(100);
//     $(".women-trousers").hide(100);
//     $(".women-skirts").hide(100);
//     $(".women-skirts-shirts").hide(100);
//     $(".women-skirts-tshirts").hide(100);
//     $(".women-trousers-shirts").hide(100);
//     $(".women-trousers-tshirts").hide(100);
//     $(".women-dress").hide(100);
//     $(".women-suit").show(120);
//     $(".women-hoddy").hide(100);
//     $(".women-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".women-types .hoddy-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".women-types-photos").show(120);
//     $(".women-shirts").hide(100);
//     $(".women-tshirts").hide(100);
//     $(".women-trousers").hide(100);
//     $(".women-skirts").hide(100);
//     $(".women-skirts-shirts").hide(100);
//     $(".women-skirts-tshirts").hide(100);
//     $(".women-trousers-shirts").hide(100);
//     $(".women-trousers-tshirts").hide(100);
//     $(".women-dress").hide(100);
//     $(".women-suit").hide(100);
//     $(".women-hoddy").show(120);
//     $(".women-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".women-types .jacket-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".women-types-photos").show(120);
//     $(".women-shirts").hide(100);
//     $(".women-tshirts").hide(100);
//     $(".women-trousers").hide(100);
//     $(".women-skirts").hide(100);
//     $(".women-skirts-shirts").hide(100);
//     $(".women-skirts-tshirts").hide(100);
//     $(".women-trousers-shirts").hide(100);
//     $(".women-trousers-tshirts").hide(100);
//     $(".women-dress").hide(100);
//     $(".women-suit").hide(100);
//     $(".women-hoddy").hide(100);
//     $(".women-jacket").show(120);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $("#prev-women-types").click(function(){
//     $(".women-types").show(120);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
//     $(".women-types-photos").hide(100);
//     $(".types-photos").hide(100);
//     $(".women-shirts").hide(100);
//     $(".women-tshirts").hide(100);
//     $(".women-trousers").hide(100);
//     $(".women-skirts").hide(100);
//     $(".women-skirts-shirts").hide(100);
//     $(".women-skirts-tshirts").hide(100);
//     $(".women-trousers-shirts").hide(100);
//     $(".women-trousers-tshirts").hide(100);
//     $(".women-dress").hide(100);
//     $(".women-suit").hide(100);
//     $(".women-hoddy").hide(100);
//     $(".women-jacket").hide(100);
// })
// /***************************************************************************/
// $(".men-types .shirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".men-types-photos").show(120);
//     $(".men-shirts").show(120);
//     $(".men-tshirts").hide(100);
//     $(".men-trousers").hide(100);
//     $(".men-trousers-shirts").hide(100);
//     $(".men-trousers-tshirts").hide(100);
//     $(".men-suit").hide(100);
//     $(".men-hoddy").hide(100);
//     $(".men-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".men-types .tshirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".men-types-photos").show(120);
//     $(".men-shirts").hide(100);
//     $(".men-tshirts").show(120);
//     $(".men-trousers").hide(100);
//     $(".men-trousers-shirts").hide(100);
//     $(".men-trousers-tshirts").hide(100);
//     $(".men-suit").hide(100);
//     $(".men-hoddy").hide(100);
//     $(".men-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".men-types .trouser-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".men-types-photos").show(120);
//     $(".men-shirts").hide(100);
//     $(".men-tshirts").hide(100);
//     $(".men-trousers").show(120);
//     $(".men-trousers-shirts").hide(100);
//     $(".men-trousers-tshirts").hide(100);
//     $(".men-suit").hide(100);
//     $(".men-hoddy").hide(100);
//     $(".men-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".men-types .trouser-shirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".men-types-photos").show(120);
//     $(".men-shirts").hide(100);
//     $(".men-tshirts").hide(100);
//     $(".men-trousers").hide(100);
//     $(".men-trousers-shirts").show(120);
//     $(".men-trousers-tshirts").hide(100);
//     $(".men-suit").hide(100);
//     $(".men-hoddy").hide(100);
//     $(".men-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".men-types .trouser-tshirt-choice").click(function(){
//     $(".men-types-photos").show(120);
//     $(".men-shirts").hide(100);
//     $(".men-tshirts").hide(100);
//     $(".men-trousers").hide(100);
//     $(".men-trousers-shirts").hide(100);
//     $(".men-trousers-tshirts").show(120);
//     $(".men-suit").hide(100);
//     $(".men-hoddy").hide(100);
//     $(".women-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".men-types .suit-choice").click(function(){
// $(".types-photos").show(120);
//     $(".men-types-photos").show(120);
//     $(".men-shirts").hide(100);
//     $(".men-tshirts").hide(100);
//     $(".men-trousers").hide(100);
//     $(".men-skirts").hide(100);
//     $(".men-skirts-shirts").hide(100);
//     $(".men-skirts-tshirts").hide(100);
//     $(".men-trousers-shirts").hide(100);
//     $(".men-trousers-tshirts").hide(100);
//     $(".men-dress").hide(100);
//     $(".men-suit").show(120);
//     $(".men-hoddy").hide(100);
//     $(".men-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".men-types .hoddy-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".men-types-photos").show(120);
//     $(".men-shirts").hide(100);
//     $(".men-tshirts").hide(100);
//     $(".men-trousers").hide(100);
//     $(".men-trousers-shirts").hide(100);
//     $(".men-trousers-tshirts").hide(100);
//     $(".men-suit").hide(100);
//     $(".men-hoddy").show(120);
//     $(".men-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".men-types .jacket-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".men-types-photos").show(120);
//     $(".men-shirts").hide(100);
//     $(".men-tshirts").hide(100);
//     $(".men-trousers").hide(100);
//     $(".men-trousers-shirts").hide(100);
//     $(".men-trousers-tshirts").hide(100);
//     $(".men-suit").hide(100);
//     $(".men-hoddy").hide(100);
//     $(".men-jacket").show(120);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $("#prev-men-types").click(function(){
//     $(".men-types").show(120);
//     $(".women-types").hide(100);
//     $(".kids-types").hide(100);
//     $(".types-photos").hide(100);
//     $(".men-types-photos").hide(100);
//     $(".men-shirts").hide(100);
//     $(".men-tshirts").hide(100);
//     $(".men-trousers").hide(100);
//     $(".men-trousers-shirts").hide(100);
//     $(".men-trousers-tshirts").hide(100);
//     $(".men-suit").hide(100);
//     $(".men-hoddy").hide(100);
//     $(".men-jacket").hide(100);
// })
// /**********************************************************************/
// $(".kids-types .shirt-choice").click(function(){
//     $(".kids-types-photos").show(120);
//     $(".kids-shirts").show(120);
//     $(".kids-tshirts").hide(100);
//     $(".kids-trousers").hide(100);
//     $(".kids-skirts").hide(100);
//     $(".kids-skirts-shirts").hide(100);
//     $(".kids-skirts-tshirts").hide(100);
//     $(".kids-trousers-shirts").hide(100);
//     $(".kids-trousers-tshirts").hide(100);
//     $(".kids-dress").hide(100);
//     $(".kids-suit").hide(100);
//     $(".kids-hoddy").hide(100);
//     $(".kids-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".kids-types .tshirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".kids-types-photos").show(120);
//     $(".kids-shirts").hide(100);
//     $(".kids-tshirts").show(120);
//     $(".kids-trousers").hide(100);
//     $(".kids-skirts").hide(100);
//     $(".kids-skirts-shirts").hide(100);
//     $(".kids-skirts-tshirts").hide(100);
//     $(".kids-trousers-shirts").hide(100);
//     $(".kids-trousers-tshirts").hide(100);
//     $(".kids-dress").hide(100);
//     $(".kids-suit").hide(100);
//     $(".kids-hoddy").hide(100);
//     $(".kids-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".kids-types .trouser-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".kids-types-photos").show(120);
//     $(".kids-shirts").hide(100);
//     $(".kids-tshirts").hide(100);
//     $(".kids-trousers").show(120);
//     $(".kids-skirts").hide(100);
//     $(".kids-skirts-shirts").hide(100);
//     $(".kids-skirts-tshirts").hide(100);
//     $(".kids-trousers-shirts").hide(100);
//     $(".kids-trousers-tshirts").hide(100);
//     $(".kids-dress").hide(100);
//     $(".kids-suit").hide(100);
//     $(".kids-hoddy").hide(100);
//     $(".kids-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".kids-types .skirt-choice").click(function(){
//     $(".kids-types-photos").show(120);
//     $(".kids-shirts").hide(100);
//     $(".kids-tshirts").hide(100);
//     $(".kids-trousers").hide(100);
//     $(".kids-skirts").show(120);
//     $(".kids-skirts-shirts").hide(100);
//     $(".kids-skirts-tshirts").hide(100);
//     $(".kids-trousers-shirts").hide(100);
//     $(".kids-trousers-tshirts").hide(100);
//     $(".kids-dress").hide(100);
//     $(".kids-suit").hide(100);
//     $(".kids-hoddy").hide(100);
//     $(".kids-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".kids-types .skirt-shirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".kids-types-photos").show(120);
//     $(".kids-shirts").hide(100);
//     $(".kids-tshirts").hide(100);
//     $(".kids-trousers").hide(100);
//     $(".kids-skirts").hide(100);
//     $(".kids-skirts-shirts").show(120);
//     $(".kids-skirts-tshirts").hide(100);
//     $(".kids-trousers-shirts").hide(100);
//     $(".kids-trousers-tshirts").hide(100);
//     $(".kids-dress").hide(100);
//     $(".kids-suit").hide(100);
//     $(".kids-hoddy").hide(100);
//     $(".kids-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".kids-types .skirt-tshirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".kids-types-photos").show(120);
//     $(".kids-shirts").hide(100);
//     $(".kids-tshirts").hide(100);
//     $(".kids-trousers").hide(100);
//     $(".kids-skirts").hide(100);
//     $(".kids-skirts-shirts").hide(100);
//     $(".kids-skirts-tshirts").show(120);
//     $(".kids-trousers-shirts").hide(100);
//     $(".kids-trousers-tshirts").hide(100);
//     $(".kids-dress").hide(100);
//     $(".kids-suit").hide(100);
//     $(".kids-hoddy").hide(100);
//     $(".kids-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".kids-types .trouser-shirt-choice").click(function(){
//     $(".kids-types-photos").show(120);
//     $(".kids-shirts").hide(100);
//     $(".kids-tshirts").hide(100);
//     $(".kids-trousers").hide(100);
//     $(".kids-skirts").hide(100);
//     $(".kids-skirts-shirts").hide(100);
//     $(".kids-skirts-tshirts").hide(100);
//     $(".kids-trousers-shirts").show(120);
//     $(".kids-trousers-tshirts").hide(100);
//     $(".kids-dress").hide(100);
//     $(".kids-suit").hide(100);
//     $(".kids-hoddy").hide(100);
//     $(".kids-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".kids-types .trouser-tshirt-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".kids-types-photos").show(120);
//     $(".kids-shirts").hide(100);
//     $(".kids-tshirts").hide(100);
//     $(".kids-trousers").hide(100);
//     $(".kids-skirts").hide(100);
//     $(".kids-skirts-shirts").hide(100);
//     $(".kids-skirts-tshirts").hide(100);
//     $(".kids-trousers-shirts").hide(100);
//     $(".kids-trousers-tshirts").show(120);
//     $(".kids-dress").hide(100);
//     $(".kids-suit").hide(100);
//     $(".kids-hoddy").hide(100);
//     $(".kids-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".kids-types .dress-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".kids-types-photos").show(120);
//     $(".kids-shirts").hide(100);
//     $(".kids-tshirts").hide(100);
//     $(".kids-trousers").hide(100);
//     $(".kids-skirts").hide(100);
//     $(".kids-skirts-shirts").hide(100);
//     $(".kids-skirts-tshirts").hide(100);
//     $(".kids-trousers-shirts").hide(100);
//     $(".kids-trousers-tshirts").hide(120);
//     $(".kids-dress").show(120);
//     $(".kids-suit").hide(100);
//     $(".kids-hoddy").hide(100);
//     $(".kids-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".kids-types .suit-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".kids-types-photos").show(120);
//     $(".kids-shirts").hide(100);
//     $(".kids-tshirts").hide(100);
//     $(".kids-trousers").hide(100);
//     $(".kids-skirts").hide(100);
//     $(".kids-skirts-shirts").hide(100);
//     $(".kids-skirts-tshirts").hide(100);
//     $(".kids-trousers-shirts").hide(100);
//     $(".kids-trousers-tshirts").hide(100);
//     $(".kids-dress").hide(100);
//     $(".kids-suit").show(120);
//     $(".kids-hoddy").hide(100);
//     $(".kids-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".kids-types .hoddy-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".kids-types-photos").show(120);
//     $(".kids-shirts").hide(100);
//     $(".kids-tshirts").hide(100);
//     $(".kids-trousers").hide(100);
//     $(".kids-skirts").hide(100);
//     $(".kids-skirts-shirts").hide(100);
//     $(".kids-skirts-tshirts").hide(100);
//     $(".kids-trousers-shirts").hide(100);
//     $(".kids-trousers-tshirts").hide(100);
//     $(".kids-dress").hide(100);
//     $(".kids-suit").hide(100);
//     $(".kids-hoddy").show(120);
//     $(".kids-jacket").hide(100);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $(".kids-types .jacket-choice").click(function(){
//     $(".types-photos").show(120);
//     $(".kids-types-photos").show(120);
//     $(".kids-shirts").hide(100);
//     $(".kids-tshirts").hide(100);
//     $(".kids-trousers").hide(100);
//     $(".kids-skirts").hide(100);
//     $(".kids-skirts-shirts").hide(100);
//     $(".kids-skirts-tshirts").hide(100);
//     $(".kids-trousers-shirts").hide(100);
//     $(".kids-trousers-tshirts").hide(100);
//     $(".kids-dress").hide(100);
//     $(".kids-suit").hide(100);
//     $(".kids-hoddy").hide(100);
//     $(".kids-jacket").show(120);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
// })
// $("#prev-kids-types").click(function(){
//     $(".kids-types").show(120);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".types-photos").hide(100);
//     $(".kids-types-photos").hide(100);
//     $(".kids-shirts").hide(100);
//     $(".kids-tshirts").hide(100);
//     $(".kids-trousers").hide(100);
//     $(".kids-skirts").hide(100);
//     $(".kids-skirts-shirts").hide(100);
//     $(".kids-skirts-tshirts").hide(100);
//     $(".kids-trousers-shirts").hide(100);
//     $(".kids-trousers-tshirts").hide(100);
//     $(".kids-dress").hide(100);
//     $(".kids-suit").hide(100);
//     $(".kids-hoddy").hide(100);
//     $(".kids-jacket").hide(100);
// })

// $("#finish-upload").click(function(){
//     $(".request-type").hide(500);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
//     $(".types-photos").hide(100);
//     $(".finish-upload-inputs").show(120);
// })
// $(".finish-photo").click(function(){
//     $(".request-type").hide(500);
//     $(".women-types").hide(100);
//     $(".men-types").hide(100);
//     $(".kids-types").hide(100);
//     $(".types-photos").hide(100);
//     $(".women-types-photos").hide(100);
//     $(".men-types-photos").hide(100);
//     $(".kids-types-photos").hide(100);
//     $(".finish-noupload-inputs").show(120);
// })


//////////////////////input inage in big image///////////////////////
function imageInputPreview() {
    var bigImage = document.querySelector('.big-image');
    var imageFile = document.querySelector('.uploud-photo').files[0];
    var reader = new FileReader();
  reader.onloadend = function () {
    bigImage.src = reader.result;
  }
  if (imageFile) {
      reader.readAsDataURL(imageFile);
  } else {
      bigImage.src = "";
  }
}

$(document).ready( function() {
    $(document).on('change', '.btn-file :file', function() {
    var input = $(this),
        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
    input.trigger('fileselect', [label]);
    });
    $('.btn-file :file').on('fileselect', function(event, label) {

        var input = $(this).parents('.input-group').find(':text'),
            log = label;

        if( input.length ) {
            input.val(log);
        } else {
            if( log ) alert(log);
        }
    });
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();   
            reader.onload = function (e) {
                $('.big-image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imgInp").change(function(){
        readURL(this);
    }); 	
});
$(".butn").click(function(){
    var x = "<button  class='btn btn-info mr-3'><i class='fas fa-check-circle'></i> Sended</button>"
    $(".butn").html(x);
})





